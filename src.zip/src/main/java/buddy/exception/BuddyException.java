package buddy.exception;

public class BuddyException extends Exception {

    public BuddyException(String message) {
        super(message);
    }

}
