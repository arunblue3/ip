package buddy.gui;

import javafx.application.Application;

/* Re-use policy
 * Code was modified from JavaFX tutorial.
 */

/**
 * A launcher class to workaround classpath issues.
 */

public class Launcher {
    public static void main(String[] args) {
        Application.launch(Main.class, args);
    }
}
